def f(x):
    return 9 * x
    print(x) # 執行不到
 
print(f(8))
