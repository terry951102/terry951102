def even_odd(num):
    if(num % 2 == 0):
        print("是偶數")
    else:
        print("是奇數")
        
number = int(input('請輸入一個數字：'))
even_odd(number)

def even_odd(num):
    if(num % 2 == 0):
        print("是偶數")
        return
    print("是奇數")
    return
        
number = int(input('請輸入一個數字：'))
even_odd(number)

